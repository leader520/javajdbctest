create view x$user_summary as
select if((`performance_schema`.`accounts`.`USER` is null), 'background',
          `performance_schema`.`accounts`.`USER`)                                AS `user`,
       sum(`stmt`.`total`)                                                       AS `statements`,
       sum(`stmt`.`total_latency`)                                               AS `statement_latency`,
       ifnull((sum(`stmt`.`total_latency`) / nullif(sum(`stmt`.`total`), 0)), 0) AS `statement_avg_latency`,
       sum(`stmt`.`full_scans`)                                                  AS `table_scans`,
       sum(`io`.`ios`)                                                           AS `file_ios`,
       sum(`io`.`io_latency`)                                                    AS `file_io_latency`,
       sum(`performance_schema`.`accounts`.`CURRENT_CONNECTIONS`)                AS `current_connections`,
       sum(`performance_schema`.`accounts`.`TOTAL_CONNECTIONS`)                  AS `total_connections`,
       count(distinct `performance_schema`.`accounts`.`HOST`)                    AS `unique_hosts`,
       sum(`mem`.`current_allocated`)                                            AS `current_memory`,
       sum(`mem`.`total_allocated`)                                              AS `total_memory_allocated`
from (((`performance_schema`.`accounts` left join `sys`.`x$user_summary_by_statement_latency` `stmt` on ((
        if((`performance_schema`.`accounts`.`USER` is null), 'background', `performance_schema`.`accounts`.`USER`) =
        `stmt`.`user`))) left join `sys`.`x$user_summary_by_file_io` `io` on ((
        if((`performance_schema`.`accounts`.`USER` is null), 'background', `performance_schema`.`accounts`.`USER`) =
        `io`.`user`)))
         left join `sys`.`x$memory_by_user_by_current_bytes` `mem`
                   on ((if((`performance_schema`.`accounts`.`USER` is null), 'background',
                           `performance_schema`.`accounts`.`USER`) = `mem`.`user`)))
group by if((`performance_schema`.`accounts`.`USER` is null), 'background', `performance_schema`.`accounts`.`USER`)
order by sum(`stmt`.`total_latency`) desc;

